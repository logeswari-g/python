#########################################################################################################
# Developer Name	:	Logeswari Gunasekaran
# Development Date	:	02/13/2023
# Project Task		:	Compare XML
# Description		:	Compare toc elements of 2 different XML's and generate excel report.
#						Excel report contains (Count of toc elements in both XML, Count of new and old)
# Regex				:	<toc:tocEntry\s+leveltype="chapter">\n\s+<heading>\n\s+<designator
#########################################################################################################

import xml.etree.ElementTree as ET
import xlsxwriter

def parse_xml(xml_filenames):
	"""
	Description	:	This function parses the xml file
	Returns		:	XML roots (List of Object)
	"""

	xml_roots = []

	for xml_filename in xml_filenames:
		tree = ET.parse(xml_filename)
		xml_roots.append(tree.getroot())

	return xml_roots

def collect_toc_info(xml_root):
	"""
	Description	:	This funtion collects 'tocEntry' element info
						1) Count the no of 'tocEntry' elements in given xml
						2) Collects the designators from each 'tocEntry'
	Returns		:	1) 'tocEntry' occurrence count (Integer)
					2) List of 'designators' (list)
	"""

	(count_of_toc_entries, designators) = (0, [])

	for statutorycode in xml_root:
		for tocentry in statutorycode[0][1][1][1]:
			designators.append(tocentry[0][0].attrib.get('value'))
			count_of_toc_entries += 1

	return (count_of_toc_entries, designators)

def compare_toc_info(toc_info):
	"""
	Description	:	This funtion compares both toc info
	Returns		:	Report Data (dict)
	"""

	# Finding missing designators (master - new)
	missing_designators = set(toc_info[0][1]).difference(set(toc_info[1][1]))

	# Finding new designators (new - master)
	new_designators = set(toc_info[1][1]).difference(set(toc_info[0][1]))

	return {
		'master_count': toc_info[0][0],
		'new_count': toc_info[1][0],
		'missing_designators': missing_designators,
		'new_designators': new_designators
	}

def generate_excel_report(data={}):
	"""
	Description	:	This funtion create excel and write the report data
	Returns		:	None
	"""

	# Create Excel workbook & worksheet
	wb = xlsxwriter.Workbook('xml_compare_report.xlsx')
	ws = wb.add_worksheet('Result')
	ws.set_column('A:E', 20)
	header_format = wb.add_format({'bold': True, 'bg_color': '#93c25d', 'font_color': 'white', 'border': 3})
	header_format.set_align('center_across')
	data_format = wb.add_format({'border': 3})
	data_format.set_align('center_across')

	# Write headers
	ws.write('A1', 'Steps', header_format)
	ws.write('B1', 'Master Toc Count', header_format)
	ws.write('C1', 'New Toc Count', header_format)
	ws.write('D1', 'Missing Designators', header_format)
	ws.write('E1', 'New Designators', header_format)
	ws.write('A2', 'Total Section Count', header_format)

	# Write report data
	ws.write('B2', data.get('master_count'), data_format)
	ws.write('C2', data.get('new_count'), data_format)
	ws.write('D2', ', '.join(data.get('missing_designators')), data_format)
	ws.write('E2', ', '.join(data.get('new_designators')), data_format)

	# Close workbook
	wb.close()

if __name__ == '__main__':
	# Parse both master & new xml
	xml_roots = parse_xml([
		"master.xml",
		"new.xml"
	])

	# Collect and compare 'tocEntry' info of both xml
	report_data = compare_toc_info(
		toc_info = [
			collect_toc_info(xml_roots[0]), # Master
			collect_toc_info(xml_roots[1]), # New
		]
	)

	# Generates excel report
	generate_excel_report(
		data = report_data
	)

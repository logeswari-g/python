
# importing openpyxl module
import openpyxl # type: ignore
import ast # type: ignore

# Give the location of the file
file1 = "ArcherApplications.xlsx"
file2 = "NewInitiativesStatus.xlsx"

# workbook object is created
wb_obj_file1 = openpyxl.load_workbook(file1)
wb_obj_file2 = openpyxl.load_workbook(file2)

sheet1 = wb_obj_file1.active
sheet2 = wb_obj_file2.active
sheet1_row = sheet1.max_row
sheet2_row = sheet2.max_row
sheet1['K1'] = 'Active_Initiative'

newInitiativeStatus = {}

for index in range(2, sheet2_row + 1):
	newInitiativeStatus[sheet2.cell(row = index, column = 1).value] = sheet2.cell(row = index, column = 2).value

newInitApp = {}

for index in range(2, sheet1_row + 1):
	newInitAppList = ast.literal_eval(sheet1.cell(row = index, column = 8).value)
	inActiveState = ['Completed', 'Cancelled', 'TEST ONLY']
	activeInitiativelist = [eachInitApp for eachInitApp in newInitAppList if eachInitApp in newInitiativeStatus.keys() and ast.literal_eval(newInitiativeStatus[eachInitApp])[0] not in inActiveState ]
	sheet1['K'+str(index)] = str(activeInitiativelist)
wb_obj_file1.save("ArcherApplications.xlsx")
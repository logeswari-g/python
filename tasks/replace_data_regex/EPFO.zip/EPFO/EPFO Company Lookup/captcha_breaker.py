"""
    Python Code to crack Captcha text.
"""
import re
import easyocr
from paddleocr import PaddleOCR, draw_ocr


paddle_ocr = PaddleOCR(use_angle_cls=True, lang='en')
reader = easyocr.Reader(['en'])

def captcha_breaker(img_path, captcha_type):
    """To break captcha using service and modules

    Args:
        img_path (str): Image path
        captcha_type (int): 1 for EasyOCR and 2 for PaddleOCR

    Returns:
        str: return OCR output
    """
    if captcha_type == 1:
        try:
            ocr_text = reader.readtext(img_path, detail=0,
                                       decoder ='wordbeamsearch', paragraph =True)
            #print(ocr_text, "OCR Text")
            return re.sub(r"\s+", "", "".join(ocr_text) if ocr_text else "")
        except Exception:
            #print(e)
            return ""
    elif captcha_type == 2:
        result = paddle_ocr.ocr(img_path, cls=True)
        #result = reader.readtext(fil, detail=0, paragraph =True)
        try:
            return re.sub(r"\s+", "", result[0][0][-1][0])
        except IndexError:
            return ""

if __name__ == "__main__":
    print(captcha_breaker(r"D:\Projects\MCA_EPFO\Data\Captcha\MCA\mca_1.jpg", 1))

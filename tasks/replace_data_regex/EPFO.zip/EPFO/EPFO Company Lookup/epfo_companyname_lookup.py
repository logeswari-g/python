# importing the requests library
from selenium import webdriver # type: ignore
from selenium.webdriver.common.keys import Keys # type: ignore
from selenium.webdriver.common.by import By # type: ignore
from selenium.webdriver.chrome.options import Options # type: ignore
import re
import time
import os
from PIL import Image
import captcha_breaker
import shutil

def searchPage(contentFileName, captchaFilename, screenshotFilename, inputCompanyName, uniqueId, fcaptchaFilePath):

	### home page ping
	driver.get("https://unifiedportal-epfo.epfindia.gov.in/publicPortal/no-auth/misReport/home/loadEstSearchHome")

	companyIdInput = driver.find_element(By.ID, "estName")
	companyIdInput.send_keys(inputCompanyName)
	
	retryCount = 1
	while (retryCount <= 3):
		captchaFilename = re.sub(r"([^>]*?Captcha_[\d]{1,})[\d\_]*?.png", r"\1_"+str(retryCount)+".png", captchaFilename)
		screenshotFilename = re.sub(r"([^>]*?Screenshot_[\d]{1,})[\d\_]*?.png", r"\1_"+str(retryCount)+".png", screenshotFilename)

		######## capturing screenshot to crop captcha
		imageCrop(screenshotFilename, captchaFilename)

		######## captcha breaking
		captchaValue = captcha_breaker.captcha_breaker(captchaFilename, 1)
		print ("captcha value - ", captchaValue)

		######## entering captcha
		captchaEnter = driver.find_element(By.ID, "captcha")
		captchaEnter.send_keys(captchaValue)
		time.sleep(3)

		######## submitting the search
		driver.find_element("xpath", '//*[@id="searchEmployer"]').click()
		time.sleep(10)
		resultSource = driver.page_source
		
		######### validation result page	
		notValidPage = re.search('<div[^>]*?>\s*Please\s*enter\s*valid\s*captcha', str(resultSource))
		fileHandling (contentFileName, 'w', resultSource)

		if not notValidPage:
			###### collecting needed datas
			dataCollection(str(resultSource), outputFileName, inputCompanyName)
			break
		else:
			##### moving failed captcha to folder
			shutil.move(captchaFilename, fcaptchaFilePath)

		if retryCount == 3 and notValidPage:
			####### writing failed input in output file
			fileHandling(outputFileName, "a", '{}\t{}\t{}\t{}\t{}\n'.format('', '', inputCompanyName, uniqueId, 'Captcha Failure'))
		retryCount += 1

def dataCollection(pageSource, outputFileName, inputCompanyName):

	#### declaring variables
	wholeblock = ''
	flag = 0

	###### capturing needed datas
	wholeblockmatch = re.search('<div[^?]*?class="dataTables_wrapper[^?]*?>([\w\W]*?)<\/tbody>', str(pageSource))
	if wholeblockmatch:
		wholeblock = wholeblockmatch.group(1)

	blocklist = re.findall('<tr[^?]*?>([\w\W]*?)<\/tr>', str(wholeblock))
	for block in blocklist:
		recordmatch = re.search('<td[^>]*?class="sorting_1">\s*([^>]*?)\s*<\/td>\s*<td[^>]*?>\s*([^>]*?)\s*<\/td>', str(block))
		if recordmatch:
			establishmentId = dataClean(recordmatch.group(1))
			establishmentName = dataClean(recordmatch.group(2))

			## writing datas in output file
			finalResult = '{}\t{}\t{}\t{}\t{}\n'.format(establishmentId, establishmentName, inputCompanyName, uniqueId, 'ResultFound')
			flag = 1
			fileHandling(outputFileName, "a", finalResult)
	
	if flag == 0:
		finalResult = '{}\t{}\t{}\t{}\t{}\n'.format('', '', inputCompanyName, uniqueId, 'NoResult')
		fileHandling(outputFileName, "a", finalResult)

def normalization(data):

	data = re.sub(' ', ' ', data)
	return data

def dataClean(data):

	data = str(data)
	data = re.sub('<[^>]*?>', ' ', data)
	data = re.sub('\s+', ' ', data)
	data = re.sub('^\s*|\s*$', '', data)

	return data

def fileHandling(filename, mode, content):

	fileToWrite = open(filename, mode)
	fileToWrite.write(content)
	fileToWrite.close()

def folderCreation():

	filepattern = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime())
	cacheFilePath = os.path.join(os.getcwd(), 'Cache')
	fcaptchaFilePath = os.path.join(os.getcwd(), 'Failed Captcha')
	outputFilePath = os.path.join(os.getcwd(), 'Output')
	captchaFilePath = os.path.join(os.getcwd(), 'Captcha')
	screenshotPath = os.path.join(os.getcwd(), 'Screenshot')
	outputFileName = "{}\MCA_company_details_extraction_{}.txt".format(outputFilePath,filepattern)
	if not os.path.exists(outputFilePath):
		os.mkdir(outputFilePath)
	if not os.path.exists(cacheFilePath):
		os.mkdir(cacheFilePath)
	if not os.path.exists(captchaFilePath):
		os.mkdir(captchaFilePath)
	if not os.path.exists(fcaptchaFilePath):
		os.mkdir(fcaptchaFilePath)
	if not os.path.exists(screenshotPath):
		os.mkdir(screenshotPath)

	return (outputFilePath, cacheFilePath, captchaFilePath, screenshotPath, outputFileName, fcaptchaFilePath)

def imageCrop(screenshotFilename, captchaFilename):

	### taking screenshot
	driver.save_screenshot(screenshotFilename)

	#### cropping captcha image
	image_obj = Image.open(screenshotFilename)
	# crop(right, up, left,down )
	cropped_image = image_obj.crop((785, 430, 1070, 515 ))
	cropped_image.save(captchaFilename)

if __name__ == "__main__":
	
	chrome_options = Options()
	chrome_options.add_experimental_option("detach", True)
	# chrome_options.add_argument('headless')
	driver = webdriver.Chrome(options=chrome_options)

	(outputFilePath, cacheFilePath, captchaFilePath, screenshotPath, outputFileName, fcaptchaFilePath) = folderCreation()

	try:
		with open('Input_Company_Name.txt', 'r') as f:
			inputDatas = f.readlines()
	except Exception as error:
		print(" Error occured while reading input file - ",str(error))

	fileHandling(outputFileName, 'w', 'Establishment ID\tEstablishment Name\tInput Company Name\tunique ID\tResult Status\n')

	for inputdata in inputDatas[1:20]:
		splitinput =  inputdata.split('\t')
		uniqueId =  splitinput[0].strip()
		inputCompanyName =  splitinput[1].strip()

		print("unique id - ", uniqueId)
		print("inputCompanyName - ", inputCompanyName)
		contentFileName = "{}\SearchPage_{}.html".format(cacheFilePath, uniqueId)
		screenshotFilename = "{}\Screenshot_{}.png".format(screenshotPath, uniqueId)
		captchaFilename = "{}\Captcha_{}.png".format(captchaFilePath, uniqueId)
		resultSource = searchPage(contentFileName, captchaFilename, screenshotFilename, inputCompanyName, uniqueId, fcaptchaFilePath)
	driver.close()



# importing the requests library
import requests
import json
import time
import os

def searchPage(inputCompanyName,contentFileName):

	# search page content fetch
	PARAMS = {'companyname':inputCompanyName}
	headers = {'Accept':'*/*', 'upgrade-insecure-requests': '1', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', "X-Requested-With": "XMLHttpRequest", 'Origin': 'https://www.mca.gov.in', 'Referer': 'https://www.mca.gov.in/mcafoportal/viewCompanyMasterData.do'}

	searchPage = requests.post(url = 'https://www.mca.gov.in/mcafoportal/cinLookup.do', params = PARAMS, headers = headers)

	time.sleep(10)

	searchContent = searchPage.text

	try:
		f = open(contentFileName, "w")
		f.write(searchContent)
		f.close()
	except Exception as error:
		print (error)

	return searchContent

def writingOutput(searchContent, outputFileName, uniqueID):

	data_json = {}
	try:
		data_json = json.loads(searchContent)
	except Exception as error:
		print ('Error occured in fetch content: '+ str(error))
	
	status = data_json.get('success')

	time.sleep(5)

	if status == 'true':
		companyDatas = data_json.get('companyList')
		for companyData in companyDatas:
			companyName = companyData.get('companyName')
			companyID = companyData.get('companyID')
			f = open(outputFileName, "a")
			f.write(companyName+"\t"+companyID+"\t"+inputCompanyName+"\t"+uniqueID+"\tResult found\n")
			f.close()

	elif status == 'false':
		f = open(outputFileName, "a")
		f.write("\t\t"+inputCompanyName+"\t"+uniqueID+"\tNo Results Found\n")
		f.close()

	else:
		f = open(outputFileName, "a")
		f.write("\t\t"+inputCompanyName+"\t"+uniqueID+"\tNo Match\n")
		f.close()

if __name__ == "__main__":
	
	filename = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime())
	cacheFilePath = os.path.join(os.getcwd(), 'Cache')
	outputFilePath = os.path.join(os.getcwd(), 'Output')
	outputFileName = "{}\MCA_company_lookup_results_{}.txt".format(outputFilePath,filename)
	if not os.path.exists(outputFilePath):
		os.mkdir(outputFilePath)
	if not os.path.exists(cacheFilePath):
		os.mkdir(cacheFilePath)

	try:
		f = open(outputFileName, "w")
		f.write("Company Registered Name\tCompany ID\tInput Company Name\tUnique ID\tResult Status\n")
		f.close()
	except Exception as error:
		print("Error occured while writing output file: "+ str(error))

	try:
		with open('Input_Company_Name.txt', 'r') as f:
			inputDatas = f.readlines()
	except Exception as error:
		print("Error occured while reading input file: "+ str(error))

	for input in inputDatas[21:50]:
		inputData = input.split('\t')
		uniqueID = inputData[0].strip()
		inputCompanyName = inputData[1].strip()

		contentFileName = "{}\SearchPage_{}.json".format(cacheFilePath,uniqueID)

		time.sleep(5)
		searchContent = searchPage(inputCompanyName, contentFileName)
		writingOutput(searchContent, outputFileName,uniqueID)

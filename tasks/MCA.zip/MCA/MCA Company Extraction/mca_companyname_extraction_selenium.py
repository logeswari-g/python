# importing the requests library
from selenium import webdriver # type: ignore
from selenium.webdriver.common.keys import Keys # type: ignore
from selenium.webdriver.common.by import By # type: ignore
from selenium.webdriver.chrome.options import Options # type: ignore
from PIL import Image
from w3lib.html import replace_entities # type: ignore
import os
import time
import re
import captcha_breaker
import shutil

def detailPage(contentFileName, captchaFilename, screenshotFilename, inputCompanyName, inputCompanyID, fcaptchaFilePath):

	retryCount = 1
	while (retryCount <= 3):
		### home page ping
		driver.get("https://www.mca.gov.in/mcafoportal/viewCompanyMasterData.do")
		
		captchaFilename = re.sub(r"([^>]*?Captcha[^>]*?).png", r"\1_"+str(retryCount)+".png", captchaFilename)
		screenshotFilename = re.sub(r"([^>]*?Screenshot[^>]*?).png", r"\1_"+str(retryCount)+".png", screenshotFilename)
		imageCrop(screenshotFilename, captchaFilename)

		######## captcha breaking
		captchaValue = captcha_breaker.captcha_breaker(captchaFilename, 1)

		time.sleep(5)
		######## entering fields
		companyIdInput = driver.find_element(By.ID, "companyID")
		companyIdInput.send_keys(inputCompanyID)
		captchaEnter = driver.find_element(By.ID, "userEnteredCaptcha")
		captchaEnter.send_keys(captchaValue)

		######## submitting the search
		driver.find_element("xpath", '//*[@id="companyLLPMasterData_0"]').submit()
		time.sleep(4)
		resultSource = driver.page_source

		resultSource = normalization(replace_entities(resultSource))
		fileHandling (contentFileName, 'w', resultSource)

		######### validation result page	
		notValidPage = re.search('<li>\s*Enter\s*valid\s*Letters\s*shown\s*\.<\/li>', str(resultSource))

		if not notValidPage:
			###### collecting needed datas
			dataCollection(str(resultSource), outputFileName, inputCompanyName, inputCompanyID)
			break
		else:
			##### moving failed captcha to folder
			shutil.move(captchaFilename, fcaptchaFilePath)

		if retryCount == 3 and notValidPage:
			####### writing failed input in output file
			fileHandling(outputFileName, "a", '{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n'.format('', '', '', '', inputCompanyName, inputCompanyID, uniqueId, 'Captcha Failure'))
		time.sleep(5)
		retryCount += 1

	return resultSource

def imageCrop(screenshotFilename, captchaFilename):

	### taking screenshot
	driver.execute_script("window.scrollTo(0, window.scrollY + 200)")
	driver.save_screenshot(screenshotFilename)

	#### cropping captcha image
	image_obj = Image.open(screenshotFilename)
	# crop(right, up, left,down )
	cropped_image = image_obj.crop((855, 385, 1200, 500 ))
	cropped_image.save(captchaFilename)

def dataCollection(pageSource, outputFileName, inputCompanyName, inputCompanyID):

	#### declaring variables
	(cin, companyName, registrationNumber, registeredAddress) = ('', '', '', '')

	###### capturing needed datas
	cinmatch = re.search('<td[^>]*?>\s*(?:CIN|FCRN)\s*<\/td>\s*<td[^>]*?>\s*([^>]*?)\s*<\/td>', pageSource)
	if cinmatch:
		cin = dataClean(cinmatch.group(1))

	companyNamematch = re.search('<td[^>]*?>\s*Company\s*Name\s*<\/td>\s*<td[^>]*?>\s*([^>]*?)\s*<\/td>', pageSource)
	if companyNamematch:
		companyName = dataClean(companyNamematch.group(1))

	registrationNumbermatch = re.search('<td[^>]*?>\s*Registration\s*Number\s*<\/td>\s*<td[^>]*?>\s*([^>]*?)\s*<\/td>', pageSource)
	if registrationNumbermatch:
		registrationNumber = dataClean(registrationNumbermatch.group(1))

	registeredAddressmatch = re.search('<td[^>]*?>\s*Registered\s*Address\s*<\/td>\s*<td[^>]*?>\s*([\w\W]*?)\s*<\/td>', pageSource)
	if registeredAddressmatch:
		registeredAddress = dataClean(registeredAddressmatch.group(1))

	## writing datas in output file
	finalResult = '{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n'.format(cin, companyName, registrationNumber, registeredAddress, inputCompanyName, inputCompanyID, uniqueId, 'ResultFound')
	fileHandling(outputFileName, "a", finalResult)

def normalization(data):

	data = re.sub(' ', ' ', data)
	return data

def dataClean(data):

	data = str(data)
	data = re.sub('<[^>]*?>', ' ', data)
	data = re.sub('\s+', ' ', data)
	data = re.sub('^\s*|\s*$', '', data)

	return data

def fileHandling(filename, mode, content):

	fileToWrite = open(filename, mode)
	fileToWrite.write(content)
	fileToWrite.close()

def folderCreation():

	filepattern = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime())
	cacheFilePath = os.path.join(os.getcwd(), 'Cache')
	fcaptchaFilePath = os.path.join(os.getcwd(), 'Failed Captcha')
	outputFilePath = os.path.join(os.getcwd(), 'Output')
	captchaFilePath = os.path.join(os.getcwd(), 'Captcha')
	screenshotPath = os.path.join(os.getcwd(), 'Screenshot')
	outputFileName = "{}\MCA_company_details_extraction_{}.txt".format(outputFilePath,filepattern)
	if not os.path.exists(outputFilePath):
		os.mkdir(outputFilePath)
	if not os.path.exists(cacheFilePath):
		os.mkdir(cacheFilePath)
	if not os.path.exists(captchaFilePath):
		os.mkdir(captchaFilePath)
	if not os.path.exists(fcaptchaFilePath):
		os.mkdir(fcaptchaFilePath)
	if not os.path.exists(screenshotPath):
		os.mkdir(screenshotPath)

	return (outputFilePath, cacheFilePath, captchaFilePath, screenshotPath, outputFileName, fcaptchaFilePath)

if __name__ == "__main__":
	chrome_options = Options()
	chrome_options.add_experimental_option("detach", True)
	chrome_options.add_argument('headless')
	driver = webdriver.Chrome(options=chrome_options)

	(outputFilePath, cacheFilePath, captchaFilePath, screenshotPath, outputFileName, fcaptchaFilePath) = folderCreation()

	with open('MCA_details_input.txt', 'r') as f:
		inputDatas = f.readlines()

	fileHandling(outputFileName, 'w', 'CIN\tCompany Name\tRegistration Number\tRegistered Address\tInput Company Name\tInput Company ID\tunique ID\tResult Status\n')

	# for input in inputDatas[1:2]:
	for input in inputDatas[1:len(inputDatas)]:
		inputData = input.split('\t')
		inputCompanyName = inputData[0].strip()
		inputCompanyID = inputData[1].strip()
		uniqueId = inputData[2].strip()

		time.sleep(10)
		contentFileName = "{}\DetailPage_{}.html".format(cacheFilePath, uniqueId)
		screenshotFilename = "{}\Screenshot_{}.png".format(screenshotPath, uniqueId)
		captchaFilename = "{}\Captcha_{}.png".format(captchaFilePath, uniqueId)
		resultSource = detailPage(contentFileName, captchaFilename, screenshotFilename, inputCompanyName, inputCompanyID, fcaptchaFilePath)
	driver.close()